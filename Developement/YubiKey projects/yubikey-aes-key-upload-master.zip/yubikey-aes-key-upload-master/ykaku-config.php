<?php

// Get a key from http://recaptcha.net/api/getkey
$publickey = "publickey";
$privatekey = "privatekey";

// AES Key Upload encrypt settings
$defaultkey = "12345678";
$recipients = "--recipient 23456789 --recipient 45678901 --recipient 67890123";

?>
